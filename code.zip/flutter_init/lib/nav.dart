import 'package:flutter/material.dart';
import 'package:flutter_init/screens/screen_home.dart';
import 'package:flutter_init/screens/screen_http.dart';
import 'package:flutter_init/screens/screen_intro.dart';

class ScreenMapper {
  static Route<dynamic> screenMappings(RouteSettings settings) {
    switch (settings.name) {
      case '/':
        return MaterialPageRoute(builder: (_) => const ScreenHome());
      case '/intro':
        return MaterialPageRoute(builder: (_) => const ScreenIntro());
            case '/http':
            return MaterialPageRoute(builder: (_) => const ScreenHttp());

      default:
        return MaterialPageRoute(
            builder: (_) => const Scaffold(
                  body: Center(child: Text('No route')),
                ));
    }
  }
}
