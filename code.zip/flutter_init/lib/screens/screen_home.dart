import 'package:flutter/material.dart';
import 'package:flutter_init/const.dart';
import 'package:flutter_init/forms/logingorm.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:flutter_init/pods/pods.dart';

class ScreenHome extends ConsumerStatefulWidget {
  const ScreenHome({Key? key}) : super(key: key);

  @override
  ConsumerState<ConsumerStatefulWidget> createState() => _ScreenHomeState();
}

class _ScreenHomeState extends ConsumerState<ScreenHome> {
  var _currentIndex = 0;

  void _doSomething(int indexFromBottom) {
    simpleLogger.i('doign tap');
    _currentIndex = indexFromBottom;
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    var g = ref.watch(menuProvider);
    var o = ref.watch(themePrefProvider);
    simpleLogger.i(o);
    return Scaffold(
      drawer: Drawer(
          child: Column(
        children: [
          const DrawerHeader(child: Text('Header')),
          ListTile(
            title: const Text('Menu'),
            onTap: () {
              _currentIndex = 1;
              Navigator.pop(context);
              simpleLogger.i(g);
              setState(() {});
            },
          ),
          ListTile(
            title: const Text('Light'),
            onTap: () async {
              await ref.read(themePrefProvider.notifier).update(1);
            },
          ),
          ListTile(
            title: const Text('Dark'),
            onTap: () async {
              await ref.read(themePrefProvider.notifier).update(0);
            },
          ),
          ListTile(
            title: const Text('Exit'),
            onTap: () {
              simpleLogger.i('Ime exiting');
            },
          )
        ],
      )),
      appBar: AppBar(
        title: Text(ref.watch(tokenPrefProvider).toString()),
      ),
      body: Column(
        children: [
          Text(ref.watch(counterProvider).toString()),
          Text(ref.watch(menuProvider).toString()),
          const Text('Maign'),
          FormLogin(),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        child: Text('inc'),
        onPressed: () async {
          ref.read(counterProvider.notifier).state++;
          var rider = ref.read(menuProvider.notifier);
          rider.state++;

          await ref.read(tokenPrefProvider.notifier).update('clear');
        },
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.black12,
        type: BottomNavigationBarType.fixed,
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.rule),
            label: 'Blocs',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.list),
            label: 'Logs',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add_chart_rounded),
            label: 'Setting',
          ),
        ],
        currentIndex: _currentIndex,
        onTap: _doSomething,
      ),
    );
  }
}

class MMMMM extends ConsumerStatefulWidget {
  const MMMMM({super.key});

  @override
  ConsumerState<ConsumerStatefulWidget> createState() => _MMMMMState();
}

class _MMMMMState extends ConsumerState<MMMMM> {
  @override
  Widget build(BuildContext context) {
    var f = ref.watch(menuProvider);
    return Container();
  }
}
