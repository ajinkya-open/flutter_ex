import 'package:flutter/material.dart';
import 'package:flutter_init/screens/screen_home.dart';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:introduction_screen/introduction_screen.dart';

class ScreenIntro extends ConsumerStatefulWidget {
  const ScreenIntro({super.key});

  @override
  ConsumerState<ConsumerStatefulWidget> createState() => _ScreenIntroState();
}

class _ScreenIntroState extends ConsumerState<ScreenIntro> {
  @override
  Widget build(BuildContext context) {
    return IntroductionScreen(
      pages: [
        PageViewModel(
          title: 'Normal chat',
          body: 'this is body',
        ),
        PageViewModel(
          title: 'Normal chat',
          body: 'this is body',
        ),
        PageViewModel(
          title: 'Normal chat',
          body: 'this is body',
        ),
      ],
      next: const Text('Next'),
      done: const Text('Done'),
      showDoneButton: true,
      onDone: () {


        Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const ScreenHome()),
        );


      },
    );
  }
}
