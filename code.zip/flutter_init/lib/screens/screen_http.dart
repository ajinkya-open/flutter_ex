import 'package:chopper/chopper.dart';
import 'package:flutter/material.dart';
import 'package:flutter_init/const.dart';
import 'package:flutter_init/pods/pods.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';




class ScreenHttp extends ConsumerStatefulWidget {
  const ScreenHttp({super.key});

  @override
  ConsumerState<ConsumerStatefulWidget> createState() => _ScreenHttpState();
}

class _ScreenHttpState extends ConsumerState<ScreenHttp> {

  @override
  Widget build(BuildContext context) {
    var HttpRide = ref.watch(HttpProvider);
    return Material(
      child: Column(  
        
        mainAxisAlignment: MainAxisAlignment.center,
        children: [  
    
          ElevatedButton(onPressed: () async {  
            Response res=await HttpRide.acction('1010');
            simpleLogger.i(res.body);
            simpleLogger.i(res.error);
          }, child: Text('one on')),
          ElevatedButton(onPressed: () async {  
            await HttpRide.acction('1000');
          }, child: Text('one off ')),
    
          ElevatedButton(onPressed: () async {  
            await HttpRide.acction('2010');
          }, child: Text('two on')),
          ElevatedButton(onPressed: () async {  
            await HttpRide.acction('2000');
          }, child: Text('two off ')),
    
          ElevatedButton(onPressed: () async {  
            await HttpRide.acction('3010');
          }, child: Text('three on')),
          ElevatedButton(onPressed: () async {  
            await HttpRide.acction('3000');
          }, child: Text('three off ')),
    
          ElevatedButton(onPressed: () async {  
            await HttpRide.acction('4010');
          }, child: Text('four on')),
          ElevatedButton(onPressed: () async {  
            await HttpRide.acction('4000');
          }, child: Text('four off ')),
        ],
      ),
    );
  }
} 