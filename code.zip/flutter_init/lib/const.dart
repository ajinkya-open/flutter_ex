
import 'package:logger/logger.dart';



import 'package:shared_preferences_riverpod/shared_preferences_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';



late SharedPreferences prefs;

var simpleLogger = Logger();
var menuWindow =0;
var navMenu = <String>['Home','Settings','Configure','Add Accessary','Exit'];

class Consts{  

static const String APP_TITLE = 'smarthomewid';
//static const  = ;

}