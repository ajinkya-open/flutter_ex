import 'package:chopper/chopper.dart';
import 'package:flutter/material.dart';
import 'package:flutter_init/const.dart';
import 'package:flutter_init/pods/pods.dart';
import 'package:flutter_init/services/chops.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class FormLogin extends ConsumerStatefulWidget {
  const FormLogin({super.key});

  @override
  ConsumerState<ConsumerStatefulWidget> createState() => _FormLoginState();
}

class _FormLoginState extends ConsumerState<FormLogin> {
  var _usernameHandler = TextEditingController();
  var _passwordHandler = TextEditingController();

  @override
  Widget build(BuildContext context) {
    var _formLoginKey = GlobalKey<FormState>();
    return Container(
      child: Form(
        key: _formLoginKey,
        child: Column(
          children: [
            Text('Login'),
            TextFormField(
              decoration: InputDecoration(
                hintText: 'username',
              ),
              controller: _usernameHandler,
            ),
            TextFormField(
              decoration: InputDecoration(
                hintText: 'password',
              ),
              controller: _passwordHandler,
            ),
            ElevatedButton(
                onPressed: () async {
                  if (_formLoginKey.currentState!.validate()) {
                    simpleLogger.i('submit');
                    var credential = {
                      'username': _usernameHandler.text,
                      'password': _passwordHandler.text
                    };
                    var restAuthApiRider = ref.watch(restAuthApiProvider);
                    Response res = await restAuthApiRider.getToken(credential);
                    simpleLogger.i(res.body['key']);

                    ref.read(tokenPrefProvider.notifier).update(res.body['key']);
                    
                    simpleLogger.i(res.error);
                  } else {
                    simpleLogger.i('not submie');
                  }
                },
                child: Text('Login')),
          ],
        ),
      ),
    );
  }
}
