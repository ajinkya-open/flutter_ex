//imports
import 'package:flutter/material.dart';
import 'package:flutter_init/const.dart';
import 'package:flutter_init/nav.dart';
//pods
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:shared_preferences_riverpod/shared_preferences_riverpod.dart';

import 'package:flutter_init/pods/pods.dart';

Future<void> main() async {

WidgetsFlutterBinding.ensureInitialized();

prefs = await SharedPreferences.getInstance();

  runApp(const ProviderScope(child: MyApp()));
}

class SharedPrefernces {
}


class MyApp extends ConsumerStatefulWidget {
  const MyApp({super.key});

  @override
  ConsumerState<ConsumerStatefulWidget> createState() => _MyAppState();
}

class _MyAppState extends ConsumerState<MyApp> {


  @override
  Widget build(BuildContext context) {
  var _theme = ref.watch(themePrefProvider);
    return MaterialApp(
      theme: ThemeData(
        primarySwatch: Colors.orange,
        brightness: _theme==0?Brightness.dark:Brightness.light,
        scaffoldBackgroundColor: Colors.orange[100],
        bottomAppBarColor: Colors.blue,
        ),
      onGenerateRoute: ScreenMapper.screenMappings,
      title: (Consts.APP_TITLE),
      initialRoute: '/',
      // home : MainScreen(),
    );
  }
}


