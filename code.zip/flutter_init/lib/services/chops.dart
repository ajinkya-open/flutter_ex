


import 'package:chopper/chopper.dart';


//part
part 'chops.chopper.dart';

//user snip_chopperset snippet 



@ChopperApi(baseUrl: '/ends')
abstract class ChopperEnd extends ChopperService {

  //////// services 
  // example
  //@Get()
  //Future<Response> getTodos();
  // edit services now here onward




  //chopper client
  static ChopperEnd create() {
  final client = ChopperClient(
    baseUrl: 'http://10.0.2.2:8000/api',
    services: [
    _$ChopperEnd(),
    ],
    converter: JsonConverter(),
  );
  return _$ChopperEnd(client);
  }
}


@ChopperApi()
abstract class ChopperSwitch extends ChopperService {

  //////// services 
  // example
  //@Get()
  //Future<Response> getTodos();
  // edit services now here onward

  @Get(path: 's?v={command}/')
  Future<Response> acction(@Path() String command);




  //chopper client
  static ChopperSwitch create() {
  final client = ChopperClient(
    baseUrl: 'http://127.0.0.1:8000/',
    services: [
    _$ChopperSwitch(),
    ],
    converter: JsonConverter(),
  );
  return _$ChopperSwitch(client);
  }
}



@ChopperApi(baseUrl: 'login/')
abstract class ChopperLogin extends ChopperService {

  //////// services 
  // example
  //@Get()
  //Future<Response> getTodos();
  // edit services now here onward

  @Post(headers: {'Content-type':'application/json'})
  Future<Response> getToken(@Body() Map<String,String> credential);



  //chopper client
  static ChopperLogin create() {
  final client = ChopperClient(
    baseUrl: 'http://127.0.0.1:8000/rest_auth/',
    services: [
    _$ChopperLogin(),
    ],
    converter: JsonConverter(),
  );
  return _$ChopperLogin(client);
  }
}
