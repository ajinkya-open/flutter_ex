// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'chops.dart';

// **************************************************************************
// ChopperGenerator
// **************************************************************************

// ignore_for_file: always_put_control_body_on_new_line, always_specify_types, prefer_const_declarations, unnecessary_brace_in_string_interps
class _$ChopperEnd extends ChopperEnd {
  _$ChopperEnd([ChopperClient? client]) {
    if (client == null) return;
    this.client = client;
  }

  @override
  final definitionType = ChopperEnd;
}

// ignore_for_file: always_put_control_body_on_new_line, always_specify_types, prefer_const_declarations, unnecessary_brace_in_string_interps
class _$ChopperSwitch extends ChopperSwitch {
  _$ChopperSwitch([ChopperClient? client]) {
    if (client == null) return;
    this.client = client;
  }

  @override
  final definitionType = ChopperSwitch;

  @override
  Future<Response<dynamic>> acction(String command) {
    final $url = 's?v=${command}/';
    final $request = Request('GET', $url, client.baseUrl);
    return client.send<dynamic, dynamic>($request);
  }
}

// ignore_for_file: always_put_control_body_on_new_line, always_specify_types, prefer_const_declarations, unnecessary_brace_in_string_interps
class _$ChopperLogin extends ChopperLogin {
  _$ChopperLogin([ChopperClient? client]) {
    if (client == null) return;
    this.client = client;
  }

  @override
  final definitionType = ChopperLogin;

  @override
  Future<Response<dynamic>> getToken(Map<String, String> credential) {
    final $url = 'login/';
    final $headers = {
      'Content-type': 'application/json',
    };

    final $body = credential;
    final $request =
        Request('POST', $url, client.baseUrl, body: $body, headers: $headers);
    return client.send<dynamic, dynamic>($request);
  }
}
