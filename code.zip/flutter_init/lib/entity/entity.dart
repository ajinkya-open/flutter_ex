


//entities for db 