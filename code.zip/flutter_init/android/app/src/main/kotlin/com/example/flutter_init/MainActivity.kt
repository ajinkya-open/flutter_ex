package com.example.flutter_init

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
